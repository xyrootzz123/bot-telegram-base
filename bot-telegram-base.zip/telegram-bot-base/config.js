module.exports = {
    botToken: 'YOUR_BOT_TOKEN_HERE', // Replace with your actual bot token
    ownerId:  null, // Set your owner ID here
};